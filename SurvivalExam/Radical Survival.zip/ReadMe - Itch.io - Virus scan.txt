Vi uploadet filen til virustotal.com og fik 1 falsk positiv ud af 60 mulige virusscanner.

Link til Itch.io - https://arns94.itch.io/radical-survival